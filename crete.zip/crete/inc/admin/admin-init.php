<?php

if (file_exists(get_template_directory() . '/inc/admin/required-plugin.php')) {
    require_once get_template_directory() . '/inc/admin/required-plugin.php';
}

