<?php wp_nav_menu( 
	array( 
	'theme_location' => 'account-menu', 
	'container_class' => 'msv-acc-menu-itemwrap',
	'menu_class' => 'msv-acc-menu-itembox',
	) 
); ?>